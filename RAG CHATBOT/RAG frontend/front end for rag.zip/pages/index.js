import ChatBox from "@/components/ChatBox";
import ScraperForm from "@/components/ScraperForm";

export default function Home() {
  return (
    <div className="container">
      <h1>RAG Chatbot with Gemini</h1>
      <ScraperForm />
      <ChatBox />
    </div>
  );
}
