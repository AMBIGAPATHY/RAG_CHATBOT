import { useState } from "react";
import axios from "axios";
import { FaPaperPlane } from "react-icons/fa";

export default function ChatBox() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;
    
    setMessages([...messages, { sender: "user", text: input }]);

    try {
      const response = await axios.post("http://127.0.0.1:8000/chat/", { message: input });
      setMessages([...messages, { sender: "user", text: input }, { sender: "bot", text: response.data.response }]);
    } catch (error) {
      setMessages([...messages, { sender: "bot", text: "Error fetching response." }]);
    }
    setInput("");
  };

  return (
    <div className="chat-container">
      <div className="chat-box">
        {messages.map((msg, index) => (
          <div key={index} className={msg.sender === "user" ? "user-msg" : "bot-msg"}>
            {msg.text}
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type a message..." />
        <button onClick={sendMessage}>
          <FaPaperPlane />
        </button>
      </div>
    </div>
  );
}
