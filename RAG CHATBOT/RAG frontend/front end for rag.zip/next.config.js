module.exports = {
    reactStrictMode: true,
  };
  