import google.generativeai as genai
from chatbot.logging_config import get_logger
from chatbot.exceptions import GeminiAPIError
from rag_chatbot_backend.config import GEMINI_API_KEY  # ✅ FIXED IMPORT

logger = get_logger(__name__)

genai.configure(api_key=GEMINI_API_KEY)

def generate_gemini_response(query, context):
    """Generates a response using Google Gemini AI."""
    try:
        prompt = f"Using the following context: {context}, answer this question: {query}"
        response = genai.chat(prompt)
        return response.text
    except Exception as e:
        logger.error(f"Gemini API error: {e}")
        raise GeminiAPIError("Error communicating with Gemini API")
