from chatbot.vector_store import retrieve_relevant_content
from chatbot.gemini_api import generate_gemini_response
from chatbot.logging_config import get_logger

logger = get_logger(__name__)

def chatbot_response(user_input):
    """Handles user input and retrieves/generates responses using Gemini API."""
    try:
        context = retrieve_relevant_content(user_input)
        response = generate_gemini_response(user_input, context)
        logger.info(f"User: {user_input} | Response: {response}")
        return response
    except Exception as e:
        logger.error(f"Chatbot processing failed: {e}")
        return "Sorry, an error occurred while processing your request."
