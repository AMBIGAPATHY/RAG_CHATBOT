import faiss
import numpy as np
from chatbot.embeddings import get_embedding
from chatbot.logging_config import get_logger
from chatbot.exceptions import RetrievalError

logger = get_logger("rag_chatbot/rag_chatbot.log")

# Path to save FAISS index
INDEX_PATH = "vector_store.index"

def create_vector_store(text_data):
    """Creates a FAISS vector store from text data."""
    try:
        vectors = np.array([get_embedding(text) for text in text_data])
        dimension = vectors.shape[1]  # Get embedding dimension

        # Create FAISS index
        index = faiss.IndexFlatL2(dimension)
        index.add(vectors)

        # Save index to file
        faiss.write_index(index, INDEX_PATH)
        logger.info("FAISS vector store created and saved.")

        return index
    except Exception as e:
        logger.error(f"FAISS initialization failed: {e}")
        raise RetrievalError("Error creating FAISS index.")

def load_vector_store():
    """Loads the FAISS vector store from file."""
    try:
        index = faiss.read_index(INDEX_PATH)
        logger.info("FAISS index loaded successfully.")
        return index
    except Exception as e:
        logger.warning(f"Failed to load FAISS index: {e}. Creating a new one.")
        return None

def retrieve_relevant_content(query):
    """Retrieves relevant content based on user query."""
    try:
        index = load_vector_store()
        if index is None:
            raise RetrievalError("No FAISS index found. Ensure data is indexed.")

        query_vector = get_embedding(query).reshape(1, -1)  # Convert to correct shape
        distances, indices = index.search(query_vector, k=3)  # Retrieve top 3 matches

        logger.info(f"Retrieved {len(indices[0])} relevant results for query: {query}")
        return indices.tolist()  # Convert to list
    except Exception as e:
        logger.error(f"Error retrieving content: {e}")
        raise RetrievalError("Failed to retrieve relevant content.")
