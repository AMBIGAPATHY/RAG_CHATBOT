import requests
from bs4 import BeautifulSoup
from .logging_config import get_logger
from .exceptions import ScraperError

logger = get_logger(__name__)

def scrape_content(url):
    """Scrapes textual content from a given URL."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, "html.parser")
        paragraphs = [p.text for p in soup.find_all("p")]
        
        if not paragraphs:
            raise ScraperError(f"No text found at {url}")

        content = " ".join(paragraphs)
        logger.info(f"Scraped {len(content)} characters from {url}")
        return content

    except requests.RequestException as e:
        logger.error(f"Request failed: {e}")
        raise ScraperError(f"Failed to fetch {url}")
