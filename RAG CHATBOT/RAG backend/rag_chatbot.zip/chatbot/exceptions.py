class ScraperError(Exception):
    """Raised when web scraping fails"""
    pass

class EmbeddingError(Exception):
    """Raised when embedding creation fails"""
    pass

class RetrievalError(Exception):
    """Raised when vector retrieval fails"""
    pass

class GeminiAPIError(Exception):
    """Raised when Google Gemini API call fails"""
    pass
