import os
import faiss
import numpy as np
from openai import OpenAI
from chatbot.logging_config import get_logger
from chatbot.exceptions import EmbeddingError
from rag_chatbot_backend.config import OPENAI_API_KEY

logger = get_logger("rag_chatbot/rag_chatbot.log")

client = OpenAI(api_key=OPENAI_API_KEY)

def get_embedding(text):
    """Generates an embedding for the given text using OpenAI API."""
    try:
        response = client.embeddings.create(input=text, model="text-embedding-ada-002")
        return np.array(response["data"][0]["embedding"], dtype=np.float32)
    except Exception as e:
        logger.error(f"Embedding generation failed: {e}")
        raise EmbeddingError("Error generating embedding")

def create_vector_store(text_data):
    """Creates a FAISS vector store from text data."""
    try:
        vectors = np.array([get_embedding(text) for text in text_data])
        index = faiss.IndexFlatL2(vectors.shape[1])
        index.add(vectors)
        logger.info("FAISS vector store created")
        return index
    except Exception as e:
        logger.error(f"FAISS initialization failed: {e}")
        raise EmbeddingError("Error creating FAISS index")
