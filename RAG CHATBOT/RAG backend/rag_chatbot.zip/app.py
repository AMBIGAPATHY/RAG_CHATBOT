import sys
import os
from fastapi import FastAPI
from pydantic import BaseModel
from chatbot.chatbot import chatbot_response
from chatbot.scraper import scrape_content
import uvicorn

# Ensure Python can find the chatbot module
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Welcome to the RAG Chatbot API!"}

class ChatRequest(BaseModel):
    message: str

class ScrapeRequest(BaseModel):
    url: str

@app.post("/chat/")
def chat(request: ChatRequest):
    """Handles chat requests"""
    return {"response": chatbot_response(request.message)}

@app.post("/scrape/")
def scrape(request: ScrapeRequest):
    """Handles web scraping"""
    return {"content": scrape_content(request.url)}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
