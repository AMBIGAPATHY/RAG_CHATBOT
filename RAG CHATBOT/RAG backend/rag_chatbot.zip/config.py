import os

# API Keys
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyDAoDerxRda-TscWcBg9rPWhTO_lbne8-k")

# FAISS Vector Store Path
FAISS_INDEX_PATH = os.getenv("FAISS_INDEX_PATH", "faiss_index.bin")




